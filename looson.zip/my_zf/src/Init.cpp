#include "zf_common_headfile.h"
//#include "motor.h"


uint8 beep=0;

void Interrupt()//中断函数
{
   Motor_Control();         // 核心：每 10ms 执行一次差速和电机 PID
}

void Init_all()
{
    system_delay_ms(500);

    gpio_set_level(BEEP, beep);//蜂鸣器初始化
    
    ips200_init("/dev/fb0");//屏幕初始化
   
    if(uvc_camera_init("/dev/video0") < 0)
        ips200_show_string(0,20,"Carmera Error!!!!!!!!");
    
    // Steer_init1();       // 舵机初始化，注释掉！
    Motor_Init1();          // 电机 PWM 初始化
    
    Motor_Argument();       // 🌟 必须取消注释！给目标速度和 PID 参数赋值
    
    ips200_full(RGB565_BLUE);
    system_delay_ms(1000);
    ips200_clear();
    pit_ms_init(5, Interrupt); // 10ms中断初始化
}