#include "motor.hpp"

/**********************************PID控制**************************************/
struct pwm_info motor_1_pwm_info;
struct pwm_info motor_2_pwm_info;

int16 encoder_Left;
int16 encoder_Right;

// 左轮变量
int16 Speed_Encoder_l;
float Speed_P_l, Speed_I_l, Speed_D_l;
int Speed_Erro_l;
int Speed_Goal_l;
int Speed_PID_OUT_l;
int Speed_Lasterro_l;
int Speed_Preverro_l;

// 右轮变量
int16 Speed_Encoder_r;
float Speed_P_r, Speed_I_r, Speed_D_r;
int Speed_Erro_r;
int Speed_Goal_r;
int Speed_PID_OUT_r;
int Speed_Lasterro_r;
int Speed_Preverro_r;

int PWM_Max=2500, PWM_Min=-2500;//PWM限幅值

// 电机差速
int16 Speed_Begin=550;//初始速度
int16 Speed_Expect=0;

float Diff_Speed_error;//左右轮差速误差
int16 Diff_SpeedL_expect, Diff_SpeedR_expect;//左右轮期望速度

// float Diff_Kp=3.784, Diff_Kd=20.160;//差速PID参数
float Diff_Kp=10.242, Diff_Kd=10.274;
float K=2.868;//差速系数
float Servo_angle=0;
float Dif=0;

float K1=0.6;//差速系数
float y,x;

void Motor_Argument()
{
    // 基础直道目标速度
    Speed_Goal_l = 300;
    Speed_Goal_r = 300;

    // 默认给期望速度赋初值，防止刚开机时差速函数未执行导致的未初始化
    Diff_SpeedL_expect = Speed_Goal_l;
    Diff_SpeedR_expect = Speed_Goal_r;

    Speed_P_l = 1.5;  //2.7 左轮P
    Speed_I_l = 1.55; //1.65左轮I
    Speed_D_l = 0;    //5

    Speed_P_r = 1.5;  //2.7 右轮P 2.4
    Speed_I_r = 1.55; //1.65右轮I 1.55
    Speed_D_r = 0;    //5 
}

void Motor_Control()
{
    // 1. 获取最新编码器数据
    encoder_Left = encoder_get_count(ENCODER_2);
    encoder_Right = -encoder_get_count(ENCODER_1); 
    
    // 2. 计算差速
    Motor_Diff_Pid1();

    // 3. 送入 PID 闭环
    Motor_PID_Left();
    Motor_PID_Right();
}
void Motor_Init1()
{   
    pwm_get_dev_info(MOTOR1_PWM, &motor_1_pwm_info);
    pwm_get_dev_info(MOTOR2_PWM, &motor_2_pwm_info);
}

void Encoder_Test1()
{
    int16 encoderlll = encoder_Left;
    int16 encoderrrr = encoder_Right;
    printf("Encoder_Left1:\t %d, Encoder_Right1:\t %d\n", encoderlll, encoderrrr);
}

void Motor_PID_Left(void)
{
    Speed_Encoder_l  = encoder_Left;
    
    // 包含差速逻辑的 Diff_SpeedL_expect 作为目标值
    Speed_Erro_l =  Diff_SpeedL_expect - Speed_Encoder_l; 
    
    // 增量式 PID 计算
    Speed_PID_OUT_l += (int)(Speed_P_l * (Speed_Erro_l - Speed_Lasterro_l)  +
                        Speed_I_l * Speed_Erro_l  +
                        Speed_D_l * (Speed_Erro_l - 2 * Speed_Lasterro_l + Speed_Preverro_l)); 

    // PWM 限幅
    if(Speed_PID_OUT_l < PWM_Min)
        Speed_PID_OUT_l = PWM_Min;
    else if(Speed_PID_OUT_l > PWM_Max)
        Speed_PID_OUT_l = PWM_Max;
        
    // 更新历史误差
    Speed_Preverro_l =  Speed_Lasterro_l;
    Speed_Lasterro_l =  Speed_Erro_l;
    
    // 左轮使用 MOTOR1，正转 DIR = 0
    if(Speed_PID_OUT_l >= 0)
    {
        gpio_set_level(MOTOR1_DIR, 0);									
        pwm_set_duty(MOTOR1_PWM, Speed_PID_OUT_l);
    }
    else						
    {
        gpio_set_level(MOTOR1_DIR, 1);									
        pwm_set_duty(MOTOR1_PWM, -Speed_PID_OUT_l);
    }
}

void Motor_PID_Right(void)
{
    // 右轮编码器数据在 Motor_Control 里已经加了负号校正极性，这里直接赋值即可
    Speed_Encoder_r  = encoder_Right; 

    // 包含差速逻辑的 Diff_SpeedR_expect 作为目标值
    Speed_Erro_r =  Diff_SpeedR_expect - Speed_Encoder_r;   

    // 增量式 PID 计算
    Speed_PID_OUT_r += (int)(Speed_P_r * (Speed_Erro_r - Speed_Lasterro_r)  +
                        Speed_I_r * Speed_Erro_r  +
                        Speed_D_r * (Speed_Erro_r - 2 * Speed_Lasterro_r + Speed_Preverro_r));
                        
    // PWM 限幅
    if(Speed_PID_OUT_r < PWM_Min)
        Speed_PID_OUT_r = PWM_Min;
    else if(Speed_PID_OUT_r > PWM_Max)
        Speed_PID_OUT_r = PWM_Max;
    
    // 修复：右轮现在正确使用了 _r 系列变量来更新历史误差
    Speed_Preverro_r =  Speed_Lasterro_r;
    Speed_Lasterro_r =  Speed_Erro_r;
    
    // 右轮使用 MOTOR2，正转 DIR = 1
    if(Speed_PID_OUT_r >= 0)
    {
        gpio_set_level(MOTOR2_DIR, 1);									
        pwm_set_duty(MOTOR2_PWM, Speed_PID_OUT_r);
    }
    else
    {
        gpio_set_level(MOTOR2_DIR, 0);									
        pwm_set_duty(MOTOR2_PWM, -Speed_PID_OUT_r);
    }
}

// 确保你在 motor.cpp 顶部包含了能获取 ImageStatus 和 Servo_Kp 的头文件
// 比如 #include "zf_common_headfile.h" 或者对应的 hpp

void Motor_Diff_Pid1()
{
    static float last_turn_error = 0;
    
    // 1. 获取图像真实偏差 (假设 39 是你调好的物理中线)
    float turn_error = ImageStatus.Det_True - 39.0f; 

    // 2. 引入控制“死区”，防止直道上因为1~2个像素的噪点而高频抖动
    if(turn_error > -2.0f && turn_error < 2.0f)
    {
        turn_error = 0;
    }

    // 3. 分段比例控制 (偏差小的时候温柔一点，偏差大的时候猛一点)
    float current_Kp = Diff_Kp;
    if(turn_error > -10.0f && turn_error < 10.0f)
    {
        current_Kp = Diff_Kp * 0.6f; 
    }
    else
    {
        current_Kp = Diff_Kp;
    }

    // 4. 转向 PD 控制器计算
    float turn_output = current_Kp * turn_error + Diff_Kd * (turn_error - last_turn_error);
    last_turn_error = turn_error;

    // 🌟 核心优化 1：放宽转向输出限幅（专治高速急弯冲出赛道）
    // 之前是 80 导致急弯差速拉不开，现在放宽到 130 (如果还转不过来可以放大到 150)
    float turn_limit = 500.0f; 
    if(turn_output > turn_limit) turn_output = turn_limit;
    if(turn_output < -turn_limit) turn_output = -turn_limit;

    // 🌟 核心优化 2：动态基础降速（专治高速飞出、低速摆头的死局）
    // 偏差 abs(turn_error) 越大，说明弯越急，减掉的速度越多。
    // 这里的 3.5f 是降速系数，系数越大，进弯刹车越狠。
    int current_base_speed = Speed_Goal_l - (int)(abs(turn_error) * 3.5f); 
    
    // 给降速设一个“底线”，防止弯道太急导致速度降到过低甚至倒车
    // 保证有足够的基础动力把车推过弯道
    if(current_base_speed < 120) current_base_speed = 120; 

    // 5. 将转向输出直接作用于左右轮 (使用动态降速后的基准速度)
    Diff_SpeedL_expect = current_base_speed + (int)turn_output;
    Diff_SpeedR_expect = current_base_speed - (int)turn_output;

    // 6. 极限保护 (防止 PWM 满载爆冲)
    if(Diff_SpeedL_expect < 0) Diff_SpeedL_expect = 0;
    if(Diff_SpeedR_expect < 0) Diff_SpeedR_expect = 0;
    
    if(Diff_SpeedL_expect > 1500) Diff_SpeedL_expect = 1500;
    if(Diff_SpeedR_expect > 1500) Diff_SpeedR_expect = 1500;
}