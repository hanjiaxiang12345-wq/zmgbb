
#include "zf_common_headfile.h"



using namespace cv;

// 定义全局变量
cv::Mat First_image;//原始图像
cv::Mat Cut_image;//裁剪后的图像
cv::Mat Gray_image;//灰度图
cv::Mat Resized_image;

uint8_t *rgay_image;    // 灰度图像数组指针
VideoCapture cap;

int8 uvc_camera_init(const char *path)
{
    cap.open(path);

    if(!cap.isOpened())
    {
        printf("find uvc camera error.\r\n");
        return -1;
    } 
    else 
    {
        printf("find uvc camera Successfully.\r\n");
    }


    cap.set(CAP_PROP_FRAME_WIDTH, UVC_WIDTH);     // 设置摄像头宽度
    cap.set(CAP_PROP_FRAME_HEIGHT, UVC_HEIGHT);    // 设置摄像头高度
    cap.set(CAP_PROP_FPS, 120);              // 显示屏幕帧率

    return 0;
}


int8 wait_image_refresh()
{
    try 
    {
        // 阻塞式等待图像刷新
        cap >> First_image;
        // cap.read(frame_rgb);
        if (First_image.empty()) 
        {
            std::cerr << "未获取到有效图像帧" << std::endl;
            return -1;
        }
        cv::flip(First_image, First_image, -1);
    } 
    catch (const cv::Exception& e) 
    {
        std::cerr << "OpenCV 异常: " << e.what() << std::endl;
        return -1;
    }

    int Cut_Width = 160;
    int Cut_Height = 60;
    int x = (First_image.cols - Cut_Width) / 2;
    int y = (First_image.rows - Cut_Height) / 2;
   
    cv::Rect roi(x, y, Cut_Width, Cut_Height);
    Cut_image = First_image(roi);//裁剪

    cv::resize(Cut_image, Resized_image, cv::Size(80, 60));//压缩
    cv::cvtColor(Resized_image, Gray_image, cv::COLOR_BGR2GRAY);
    //cv::cvtColor(Cut_image, Gray_image, cv::COLOR_BGR2GRAY);// rgb转灰度

    // cv对象转指针
    rgay_image = reinterpret_cast<uint8_t *>(Gray_image.ptr(0));

    return 0;
}



