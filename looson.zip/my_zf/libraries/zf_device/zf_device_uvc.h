#ifndef _zf_driver_uvc_h
#define _zf_driver_uvc_h


#include "zf_common_typedef.h"
#include <opencv2/imgproc/imgproc.hpp>  // for cv::cvtColor
#include <opencv2/highgui/highgui.hpp> // for cv::VideoCapture



#define UVC_WIDTH   160
#define UVC_HEIGHT  120
#define UVC_FPS     60


extern cv::Mat First_image;//ԭʼͼ��
extern cv::Mat Cut_image;//�ü����ͼ��
extern cv::Mat Gray_image;//�Ҷ�ͼ
extern cv::Mat Resized_image;//ѹ��ͼ��

extern uint8_t *rgay_image; 
int8 uvc_camera_init(const char *path);
int8 wait_image_refresh();

using namespace cv;
//VideoCapture cap;
#endif
